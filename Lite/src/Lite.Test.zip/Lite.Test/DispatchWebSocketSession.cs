﻿//#define __V66__

#if __V66__
using SuperSocket.WebSocket;
#else
using SuperWebSocket;
#endif

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lite.Test
{
    public class DispatchWebSocketSession : WebSocketSession<DispatchWebSocketSession>
    {
        protected override int GetMaxRequestLength()
        {
            return 1024 * 2;
        }
    }
}
